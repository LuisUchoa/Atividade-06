package com.example.enviarsms;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_SEND_SMS = 123;
    private Button mButtonSendSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mButtonSendSms = findViewById(R.id.button_send_sms);
        mButtonSendSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Verifica se a permissão para enviar SMS foi concedida
                if (ContextCompat.checkSelfPermission(MainActivity.this,
                        Manifest.permission.SEND_SMS)
                        != PackageManager.PERMISSION_GRANTED) {
                    // Se a permissão ainda não foi concedida, solicita ao usuário
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.SEND_SMS},
                            PERMISSION_SEND_SMS);
                } else {
                    // Se a permissão foi concedida, envia o SMS após 15 segundos
                    sendDelayedSms();
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_SEND_SMS: {
                // Se a permissão foi concedida, envia o SMS após 15 segundos
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    sendDelayedSms();
                } else {
                    // Se a permissão foi negada, mostra uma mensagem de erro
                    Toast.makeText(MainActivity.this,
                            "Permissão para enviar SMS negada",
                            Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    private void sendDelayedSms() {
        // Cria uma intent para enviar o SMS
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:" + Uri.encode("123456789"))); // Número do destinatário
        intent.putExtra("sms_body", "Esta é uma mensagem de teste"); // Texto da mensagem

        // Cria um PendingIntent para ser executado após 15 segundos
        PendingIntent pi = PendingIntent.getActivity(MainActivity.this, 0, intent, 0);
        SmsManager smsManager = SmsManager.getDefault();

        // Agenda o envio do SMS após 15 segundos
        smsManager.sendTextMessage("123456789", null, "Esta é uma mensagem de teste", pi, null);

        // Mostra uma mensagem informando que o SMS será enviado após 15 segundos
        Toast.makeText(MainActivity.this, "SMS será enviado após 15 segundos", Toast.LENGTH_SHORT).show();
    }
}
;
