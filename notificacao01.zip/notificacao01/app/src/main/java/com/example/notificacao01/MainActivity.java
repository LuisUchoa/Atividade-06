package com.example.notificacao01;

import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class MainActivity extends AppCompatActivity {

    private static final int NOTIFICATION_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button notifyButton = findViewById(R.id.button_notify);
        notifyButton.setOnClickListener(v -> {
            // Delay de 10 segundos antes de mostrar a notificação
            Handler handler = new Handler();
            handler.postDelayed(() -> {
                // Cria a notificação
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this, "channelId")
                        .setSmallIcon(R.drawable.notification_icon)
                        .setContentTitle("Notificação")
                        .setContentText("Esta é uma notificação de exemplo.");

                // Mostra a notificação
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify(NOTIFICATION_ID, builder.build());
            }, 10000);
        });
    }
}
